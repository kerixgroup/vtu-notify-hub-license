# vtu-notify-hub-license

This tiny public repo is the remote kill-switch for VTU Notify Hub.

Every installed copy of the plugin reads `blocklist.json` from this
repo every few hours. To revoke a specific site's license (e.g. after
a chargeback), add its license key (shown on that site's
Notify Hub → Dashboard & License page) to the `blocked` array below
and commit — no server or code required, just edit the file here on
GitHub.

Example:

```json
{
  "blocked": ["a1b2c3d4e5f6g7h8i9j0"]
}
```
